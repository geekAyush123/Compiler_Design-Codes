%{
#include <stdio.h>
int count = 0;
int yylex(void);
int yyerror(char *s);
%}

%token A

%%
S : P      { printf("Total matching parentheses: %d\n", count); }
  ;

P : '(' P ')'   { count++; }
  | A
  ;
%%

int main(void) {
    yyparse();
    return 0;
}

int yyerror(char *s) {
    printf("%s\n", s);
    return 0;
}