//lab5 - Write a Yacc program to check if the entered statement is a valid arithmetic expression.

%{
#include <stdio.h>
#include <stdlib.h>
%}

/* Token declarations */
%token NUMBER

/* Grammar rules */
%%

input:
    expr '\n'   { printf("Valid arithmetic expression.\n"); exit(0); }
    ;

expr:
    expr '+' term
    | expr '-' term
    | term
    ;

term:
    term '*' factor
    | term '/' factor
    | factor
    ;

factor:
    NUMBER
    | '(' expr ')'
    ;

%%

/* Lexical analyzer (Lex) */
int yylex() {
    int c;
    while ((c = getchar()) == ' ' || c == '\t'); // Skip whitespace

    if (isdigit(c)) {
        ungetc(c, stdin);
        scanf("%d", &yylval);
        return NUMBER;
    }

    if (c == '\n') return '\n';

    return c;
}

int main() {
    printf("Enter an arithmetic expression: ");
    yyparse();
    return 0;
}

int yyerror(const char *s) {
    fprintf(stderr, "Invalid arithmetic expression.\n");
    exit(1);
}