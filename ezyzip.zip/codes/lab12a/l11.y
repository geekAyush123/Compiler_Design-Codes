%{
#include <stdio.h>
#include <stdlib.h>
void yyerror(const char *s);
int yylex(void);
%}

%token DIGIT

%left '+' '-'
%left '*'
%left '(' ')'

%%

exp:   exp '+' term { printf("exp -> exp + term: %d + %d = %d\n", $1, $3, $1 + $3); $$ = $1 + $3; }
     | exp '-' term { printf("exp -> exp - term: %d - %d = %d\n", $1, $3, $1 - $3); $$ = $1 - $3; }
     | term { printf("exp -> term: %d\n", $1); $$ = $1; }
     ;

term:   term '*' factor { printf("term -> term * factor: %d * %d = %d\n", $1, $3, $1 * $3); $$ = $1 * $3; }
      | factor { printf("term -> factor: %d\n", $1); $$ = $1; }
      ;

factor: '(' exp ')' { printf("factor -> (exp): %d\n", $2); $$ = $2; }
      | DIGIT { printf("factor -> digit: %d\n", $1); $$ = $1; }
      ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}

int main() {
    printf("Enter an arithmetic expression (e.g., (2+(3*4))):\n");
    yyparse();
    return 0;
}