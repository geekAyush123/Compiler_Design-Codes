#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

typedef enum {
    NODE_INT,
    NODE_ADD,
    NODE_SUB,
    NODE_MUL,
    NODE_DIV
} NodeType;

typedef struct ASTNode {
    NodeType type;
    int value;
    struct ASTNode *left, *right;
} ASTNode;

// Globals for parsing
const char *input;
int pos = 0;

// Forward declarations
ASTNode* parseExpr();
void printAST(ASTNode* node, int level);

// Create a new integer node
ASTNode* newIntNode(int value) {
    ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
    node->type = NODE_INT;
    node->value = value;
    node->left = node->right = NULL;
    return node;
}

// Create a new operator node
ASTNode* newOpNode(NodeType type, ASTNode* left, ASTNode* right) {
    ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
    node->type = type;
    node->left = left;
    node->right = right;
    return node;
}

// Skip whitespace
void skipWhitespace() {
    while (isspace(input[pos])) pos++;
}

// Peek the next character
char peek() {
    skipWhitespace();
    return input[pos];
}

// Get the next character
char get() {
    skipWhitespace();
    return input[pos++];
}

// Parse a full multi-digit number
int parseNumber() {
    int value = 0;
    while (isdigit(peek())) {
        value = value * 10 + (get() - '0');
    }
    return value;
}

// Parse factor: int or (expr)
ASTNode* parseFactor() {
    char c = peek();
    if (isdigit(c)) {
        int value = parseNumber();
        return newIntNode(value);
    } else if (c == '(') {
        get(); // consume '('
        ASTNode* node = parseExpr();
        if (peek() == ')') {
            get(); // consume ')'
        } else {
            printf("Error: expected ')'\n");
            exit(1);
        }
        return node;
    } else {
        printf("Error: unexpected character '%c'\n", c);
        exit(1);
    }
}

// Parse term: factor ((* or /) factor)*
ASTNode* parseTerm() {
    ASTNode* node = parseFactor();
    while (1) {
        char op = peek();
        if (op == '*' || op == '/') {
            get();
            ASTNode* right = parseFactor();
            node = newOpNode(op == '*' ? NODE_MUL : NODE_DIV, node, right);
        } else {
            break;
        }
    }
    return node;
}

// Parse expression: term ((+ or -) term)*
ASTNode* parseExpr() {
    ASTNode* node = parseTerm();
    while (1) {
        char op = peek();
        if (op == '+' || op == '-') {
            get();
            ASTNode* right = parseTerm();
            node = newOpNode(op == '+' ? NODE_ADD : NODE_SUB, node, right);
        } else {
            break;
        }
    }
    return node;
}

// Print the AST (pre-order traversal)
void printAST(ASTNode* node, int level) {
    if (!node) return;

    for (int i = 0; i < level; i++) {
        printf("  ");
    }

    switch (node->type) {
        case NODE_INT:
            printf("INT: %d\n", node->value);
            break;
        case NODE_ADD:
            printf("ADD\n");
            break;
        case NODE_SUB:
            printf("SUB\n");
            break;
        case NODE_MUL:
            printf("MUL\n");
            break;
        case NODE_DIV:
            printf("DIV\n");
            break;
        default:
            break;
    }

    if (node->left) printAST(node->left, level + 1);
    if (node->right) printAST(node->right, level + 1);
}

int tempCount = 0;

// Generate three-address code
int generateCode(ASTNode* node) {
    if (!node) return -1;

    if (node->type == NODE_INT) {
        int reg = tempCount++;
        printf("MOV R%d, %d\n", reg, node->value);
        return reg;
    }

    int leftReg = generateCode(node->left);
    int rightReg = generateCode(node->right);
    int resultReg = tempCount++;

    switch (node->type) {
        case NODE_ADD:
            printf("ADD R%d, R%d, R%d\n", resultReg, leftReg, rightReg);
            break;
        case NODE_SUB:
            printf("SUB R%d, R%d, R%d\n", resultReg, leftReg, rightReg);
            break;
        case NODE_MUL:
            printf("MUL R%d, R%d, R%d\n", resultReg, leftReg, rightReg);
            break;
        case NODE_DIV:
            printf("DIV R%d, R%d, R%d\n", resultReg, leftReg, rightReg);
            break;
        default:
            break;
    }

    return resultReg;
}

// Free the AST
void freeAST(ASTNode* node) {
    if (!node) return;
    freeAST(node->left);
    freeAST(node->right);
    free(node);
}

int main() {
    char buffer[200];
    printf("Enter arithmetic expression(use parentheses): ");
    fgets(buffer, sizeof(buffer), stdin);

    input = buffer;
    pos = 0;
    tempCount = 0;

    ASTNode* root = parseExpr();

    printf("\nAbstract Syntax Tree (AST):\n");
    printAST(root, 0);

    printf("\nGenerated Machine Code (Three-Address Code):\n");
    generateCode(root);

    freeAST(root);
    return 0;
}
