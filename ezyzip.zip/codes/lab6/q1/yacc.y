%{
#include <stdio.h>
#include <stdlib.h>

void yyerror(const char *s);
int yylex();
%}

%token INT FLOAT CHAR DOUBLE IDENTIFIER SEMICOLON NUMBER EQUAL LBRAC RBRAC LCUR RCUR COMMA

%%

declaration:
    type IDENTIFIER SEMICOLON { printf("Valid declaration statement.\n"); }
    | type IDENTIFIER EQUAL NUMBER SEMICOLON { printf("Valid declaration with initialization.\n"); }
    | type IDENTIFIER LBRAC NUMBER RBRAC SEMICOLON {printf("Valid array declearation.\n");}
    | type IDENTIFIER LBRAC NUMBER RBRAC EQUAL LCUR number_list RCUR SEMICOLON {printf("Valid array declearation with initialization.\n");}
    ;

type:
    INT | FLOAT | CHAR | DOUBLE
    ;

number_list:
    NUMBER |
    number_list COMMA NUMBER
    ;

%%

void yyerror(const char *s) {
    printf("Error: %s\n", s);
}

int main() {
    printf("Enter a declarative statement:\n");
    yyparse();
    return 0;
}
