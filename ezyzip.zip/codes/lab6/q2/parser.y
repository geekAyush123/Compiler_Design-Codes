%{
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
%}

/* Token declarations */
%token NUMBER
%token LT GT LTE GTE EQ NEQ

%%

/* Grammar rules */
input:
    rel_expr '\n'   { printf("Valid relational expression.\n"); exit(0); }
    ;

rel_expr:
    expr LT expr
    | expr GT expr
    | expr LTE expr
    | expr GTE expr
    | expr EQ expr
    | expr NEQ expr
    ;

expr:
    expr '+' term
    | expr '-' term
    | term
    ;

term:
    term '*' factor
    | term '/' factor
    | factor
    ;

factor:
    NUMBER
    | '(' expr ')'
    ;

%%

/* Lexical analyzer (Lex) */
int yylex() {
    int c;
    while ((c = getchar()) == ' ' || c == '\t'); // Skip whitespace

    if (isdigit(c)) {
        ungetc(c, stdin);
        scanf("%d", &yylval);
        return NUMBER;
    }

    if (c == '<') {
        c = getchar();
        if (c == '=') return LTE;
        ungetc(c, stdin);
        return LT;
    }

    if (c == '>') {
        c = getchar();
        if (c == '=') return GTE;
        ungetc(c, stdin);
        return GT;
    }

    if (c == '=') {
        c = getchar();
        if (c == '=') return EQ;
        ungetc(c, stdin);
        return '=';
    }

    if (c == '!') {
        c = getchar();
        if (c == '=') return NEQ;
        ungetc(c, stdin);
        return '!';
    }

    if (c == '\n') return '\n';

    return c;
}

int main() {
    printf("Enter a relational expression: ");
    yyparse();
    return 0;
}

int yyerror(const char *s) {
    fprintf(stderr, "Invalid relational expression.\n");
    exit(1);
}