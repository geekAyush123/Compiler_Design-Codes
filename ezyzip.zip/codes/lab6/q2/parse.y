%{
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int yylex();
%}

%token NUMBER
%token LT GT LTE GTE EQ NEQ

%%

input:
    rel_expr '\n'   { printf("Valid relational expression.\n"); exit(0); }
    ;

rel_expr:
    expr LT expr
    | expr GT expr
    | expr LTE expr
    | expr GTE expr
    | expr EQ expr
    | expr NEQ expr
    ;

expr:
    expr '+' term
    | expr '-' term
    | term
    ;

term:
    term '*' factor
    | term '/' factor
    | factor
    ;

factor:
    NUMBER
    | '(' expr ')'
    ;

%%

int yyerror(const char *s) {
    fprintf(stderr, "Invalid relational expression.\n");
    exit(1);
}

int main() {
    printf("Enter a relational expression: ");
    yyparse();
    return 0;
}
