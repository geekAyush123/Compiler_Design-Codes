%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void yyerror(const char *s);
int yylex(void);

char *result;  // <- move this HERE, before the grammar
%}

%union {
    char *str;
}

%token <str> NUM
%type <str> E T F

%%

E : E '+' T {
               char *buf = malloc(strlen($1) + strlen($3) + 3);
               sprintf(buf, "%s %s +", $1, $3);
               $$ = buf;
               result = $$;
            }
  | T {
        $$ = strdup($1);
        result = $$;
     }
  ;

T : T '*' F    {
                  char *buf = malloc(strlen($1) + strlen($3) + 3);
                  sprintf(buf, "%s %s *", $1, $3);
                  $$ = buf;
               }
  | F          {
                  $$ = strdup($1);
               }
  ;

F : '(' E ')'  {
                  $$ = strdup($2);
               }
  | NUM        {
                  $$ = strdup($1);
               }
  ;

%%

int main() {
    if (yyparse() == 0) {
        printf("Postfix: %s\n", result);
    }
    return 0;
}

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}

int yywrap(){ return 1; }
