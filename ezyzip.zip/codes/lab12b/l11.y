%{
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

void yyerror(char *);
int yylex(void);

/* Function to find the maximum value in an array */
int find_max(int values[], int count) {
    int max = values[0];
    int i=1;
    for ( i = 1; i < count; i++) {
        if (values[i] > max) {
            max = values[i];
        }
    }
    return max;
}

/* Function to find the minimum value in an array */
int find_min(int values[], int count) {
    int min = values[0];
    int i=1;
    for ( i = 1; i < count; i++) {
        if (values[i] < min) {
            min = values[i];
        }
    }
    return min;
}
%}

%union {
    int num;
    struct {
        int values[100];  /* Array to store values */
        int count;        /* Number of values */
    } list;
}

%token <num> NUMBER
%token PLUS MULT MAX MIN LPAREN RPAREN

%type <list> expr_list
%type <num> expr

%%

program:
    expr                    { printf("%d\n", $1); }
    ;

expr:
    LPAREN PLUS expr_list RPAREN {
        /* Calculate sum of all numbers in the list */
        int sum = 0;
        int i=0;
        for ( i = 0; i < $3.count; i++) {
            sum += $3.values[i];
        }
        $$ = sum;
    }
    | LPAREN MULT expr_list RPAREN {
        /* Calculate product of all numbers in the list */
        int product = 1;
        int i=0;
        for ( i = 0; i < $3.count; i++) {
            product *= $3.values[i];
        }
        $$ = product;
    }
    | LPAREN MAX expr_list RPAREN {
        /* Find maximum value in the list */
        $$ = find_max($3.values, $3.count);
    }
    | LPAREN MIN expr_list RPAREN {
        /* Find minimum value in the list */
        $$ = find_min($3.values, $3.count);
    }
    ;

expr_list:
    NUMBER {
        /* Initialize the list with the first number */
        $$.values[0] = $1;
        $$.count = 1;
    }
    | expr_list NUMBER {
        /* Add a number to the list */
        if ($1.count < 100) {
            $$.count = $1.count + 1;
            memcpy($$.values, $1.values, $1.count * sizeof(int));
            $$.values[$1.count] = $2;
        } else {
            yyerror("Too many arguments in expression");
            YYABORT;
        }
    }
    ;

%%

void yyerror(char *s) {
    fprintf(stderr, "Error: %s\n", s);
}

int main(void) {
    yyparse();
    return 0;
}