%{
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "calc.h"

extern int yylex();
%}

%union {
    int intVal;
    Fractional fracVal;
    double doubleVal;
}

%token <intVal> B
%token DOT

%type <intVal> integer_L
%type <fracVal> fractional_L
%type <doubleVal> S

%%

input: /* empty */
     | input S { printf("Decimal value: %.3f\n", $2); }
     ;

S: integer_L DOT fractional_L {
        $$ = (double)$1 + ((double)$3.value / pow(2, $3.digits));
    }
 | integer_L { $$ = (double)$1; }
 ;

integer_L: integer_L B { $$ = $1 * 2 + $2; }
         | B { $$ = $1; }
         ;

fractional_L: fractional_L B { 
                  $$.value = $1.value * 2 + $2;
                  $$.digits = $1.digits + 1;
              }
            | B { 
                  $$.value = $1;
                  $$.digits = 1;
              }
            ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}

int main() {
    yyparse();
    return 0;
}
