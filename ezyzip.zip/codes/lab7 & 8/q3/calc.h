#ifndef CALC_H
#define CALC_H

typedef struct {
    int value;
    int digits;
} Fractional;

void yyerror(const char *s);

#endif
