%{
#include <stdio.h>
#include <stdlib.h>

int yylex();
void yyerror(const char *s);
int result;
%}

%token NUMBER

%left '+' '-'
%left '*'
%nonassoc UMINUS

%%

input  : exp { result = $1; printf("Result = %d\n", result); }
       ;

exp    : exp '+' term    { printf("exp -> exp + term\n"); $$ = $1 + $3; }
       | exp '-' term    { printf("exp -> exp - term\n"); $$ = $1 - $3; }
       | term            { printf("exp -> term\n"); $$ = $1; }
       ;

term   : term '*' factor { printf("term -> term * factor\n"); $$ = $1 * $3; }
       | factor          { printf("term -> factor\n"); $$ = $1; }
       ;

factor : '(' exp ')'     { printf("factor -> (exp)\n"); $$ = $2; }
       | NUMBER          { printf("factor -> number\n"); $$ = $1; }
       ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}

int main() {
    yyparse();
    return 0;
}