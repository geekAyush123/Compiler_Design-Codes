# include <stdio.h>
#include <ctype.h>
#include <string.h>

#define MAX_LEN 100

const char *keywords[] = {"for", "while", "if", "else", "return", "int", "float", "char", "const", "include", "define","auto"};
const int num_keywords = 12;

// check if string is keyword
int is_key_word(char *word)
{
    for (int i = 0; i < num_keywords; i++)
    {
        if (strcmp(keywords[i], word) == 0)
            return 1;
    }
    return 0;
}

// check if operator is present
int is_operator(char ch)
{
    return (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '|' || ch == '&' || ch == '<' || ch == '>');
}

// check if character is separator
int is_separator(char ch)
{
    return (ch == ',' || ch == ';' || ch == '(' || ch == ')' || ch == '{' || ch == '}' || ch == ' ' || ch == '#');
}

// check if string is valid identifier
int is_identifier(char *word)
{
    if (isalpha(word[0]) || word[0] == '_')
    {
        for (int i = 1; word[i] != '\0'; i++)
        {
            if (!isalnum(word[i]) && word[i] != '_')
            {
                return 0;
            }
        }
    }
    return 1;
}



// check if character is part of a number
int is_number(char ch)
{
    return (isdigit(ch) || ch == '.');
}

// tokenizer
void tokenizer(char *input)
{
    char word[MAX_LEN];
    int j = 0;
    
    for (int i = 0; input[i] != '\0'; i++)
    {
        char ch = input[i];

        // Skip whitespace
        if (isspace(ch))
            continue;

        // Handle numbers (integers or floats)
        if (is_number(ch))
        {
            word[j++] = ch;
            // Continue adding digits or decimal point for float numbers
            while (isdigit(input[i + 1]) || (input[i + 1] == '.' && isdigit(input[i + 2])))
            {
                word[j++] = input[++i];
            }
            word[j] = '\0'; 
            printf("Number: %s\n", word);
            j = 0; 
        }
        // Handle identifiers or keywords
        else if (isalpha(ch) || ch == '_')
        {
            word[j++] = ch; // Add character to word
            while ((isalnum(input[i + 1]) || input[i + 1] == '_') ) 
            {
                word[j++] = input[++i];
            }
            word[j] = '\0';
            j = 0;  

            if (is_key_word(word))
            {
                printf("Keyword: %s\n", word);
            }
            else if (is_identifier(word))
            {
                printf("Identifier: %s\n", word);
            }
        }
        else if (is_operator(ch)) 
        {
            if ((ch == '+' || ch == '-' || ch == '<' || ch == '>') && input[i + 1] == ch)
            {
                printf("Operator: %c%c\n", ch, ch);
                i++; 
            }
            else
            {
                printf("Operator: %c\n", ch);
            }
        }
        else if (is_separator(ch)) 
        {
            printf("Separator: %c\n", ch);
        }
    }
}

int main()
{
    char input[] = "#include <stdio.h> int main() { int a-- = 10; float pi = 3.14; if (a > 5) return a; }";
    tokenizer(input);
    return 0;
}
